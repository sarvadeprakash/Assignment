﻿using Assignment.Data;
using Assignment.Data.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment.Repository
{
    public class UnitOfWork
    {
        private DBContext context = new DBContext();
        private GenericRepository<Contacts> _contactRepository;


        public GenericRepository<Contacts> ContactRepository
        {
            get
            {
                if (this._contactRepository == null)
                {
                    this._contactRepository = new GenericRepository<Contacts>(context);
                }
                return _contactRepository;
            }
        }


        public void Save()
        {
            context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
