﻿using Assignment.Data.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment.Data
{
    public partial class DBContext : DbContext
    {
        public DBContext()
            : base("Name=EmployeeContext")
        {

        }

        public DbSet<Contacts> Post { get; set; }
        

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Contacts>()
            .HasKey(e => e.ContactID);

          

            //one-to-many 
            //modelBuilder.Entity<Post>()
            //            .HasRequired<Blog>(s => s.Blog)
            //            .WithMany(s => s.Post)
            //            .HasForeignKey(s => s.BlogId);


        }
    }
}
