﻿using Assignment.Data.Data;
using Assignment.ErrorHelper;
using Assignment.Repository;
using AttributeRouting.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Assignment.Controllers
{
    [RoutePrefix("v1/Contacts/Contact")]
    public class ContactController : ApiController
    {
        private UnitOfWork unitOfWork = new UnitOfWork();
        // GET api/contact
        [GET("allContacts")]
        [GET("all")]
        public HttpResponseMessage Get()
        {
            var xcontacts = unitOfWork.ContactRepository.Get(orderBy: q => q.OrderBy(d => d.ContactID));
            var contactEntities = xcontacts as List<Contacts> ?? xcontacts.ToList();
            if (contactEntities.Any())
                return Request.CreateResponse(HttpStatusCode.OK, contactEntities);

            throw new ApiDataException(1000, "Contacts not found", HttpStatusCode.NotFound);
        }

        [GET("contactid/{id?}")]
        [GET("particularcontact/{id?}")]
        public HttpResponseMessage Get(int id)
        {
            if (id > 0)
            {
                var contacts = unitOfWork.ContactRepository.GetByID(id);
                if (contacts != null)
                    return Request.CreateResponse(HttpStatusCode.OK, contacts);

                throw new ApiDataException(1001, "No contact found for this id.", HttpStatusCode.NotFound);
            }
            throw new ApiException() { ErrorCode = (int)HttpStatusCode.BadRequest, ErrorDescription = "Bad Request..." };
        }

        // POST api/contact
        [POST("Create")]
        [POST("Register")]
        public HttpResponseMessage Post([FromBody] Contacts contactEntity)
        {
            try
            {
                unitOfWork.ContactRepository.Insert(contactEntity);
                unitOfWork.Save();
                var result = new { Status = true, Message = "Contact is created." };
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                throw new ApiException() { ErrorCode = (int)HttpStatusCode.BadRequest, ErrorDescription = ex.Message };
            }

        }

        [PUT("Update/contactid/{id}")]
        [PUT("Modify/contactid/{id}")]
        public HttpResponseMessage Put(int id, [FromBody] Contacts contactEntity)
        {
            try
            {
                if (id > 0)
                {
                    unitOfWork.ContactRepository.Update(contactEntity);
                    unitOfWork.Save();
                    var result = new { Status = true, Message = "Contact is updated." };
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
                throw new ApiDataException(1001, "No contact found for this id.", HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                throw new ApiException() { ErrorCode = (int)HttpStatusCode.BadRequest, ErrorDescription = ex.Message };
            }
        }

        [DELETE("remove/productid/{id}")]
        [DELETE("clear/productid/{id}")]
        [PUT("delete/productid/{id}")]
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                if (id > 0)
                {
                    unitOfWork.ContactRepository.Delete(id);
                    unitOfWork.Save();
                    var result = new { Status = true, Message = "Contact is updated." };
                    return Request.CreateResponse(HttpStatusCode.OK, result);

                }
                throw new ApiException() { ErrorCode = (int)HttpStatusCode.BadRequest, ErrorDescription = "Bad Request..." };
            }
            catch (Exception ex)
            {
                throw new ApiDataException(1002, "Contact is already deleted or not exist in system. Error :- " + ex.Message, HttpStatusCode.NoContent);
            }
            
        }
    }
}
